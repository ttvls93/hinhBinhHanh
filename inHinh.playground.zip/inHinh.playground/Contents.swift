import UIKit

func hinhTG(width: Int) {
    for rowIndex in 0..<(width + 1) / 2 {
        var result = ""
        for cotIndex in 0..<(width + rowIndex) {
            if cotIndex < rowIndex {
                result += "   "
            }else {
                result = result + "* "
            }
        }
        print(result)
    }
}
hinhTG(width: 7)
